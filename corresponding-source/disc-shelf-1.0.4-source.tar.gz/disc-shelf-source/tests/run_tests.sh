#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
make host -j4 >/dev/null
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
export SHELF_ENGINE_TEST_BIN="$scratch/engine"
export SHELF_PAGING_TEST_BIN="$scratch/paging"
export SHELF_RECOVERY_TEST_BIN="$scratch/recovery"
export SHELF_PARSER_TEST_BIN="$scratch/parser"
export ASAN_OPTIONS=detect_leaks=0
common='src/engine.c src/net.c src/json.c build/host/vendor/sqlite3.o'
cc -g -fsanitize=address,undefined -pthread -I src -I vendor tests/engine_driver.c $common -ldl -lm -o "$SHELF_ENGINE_TEST_BIN"
cc -g -fsanitize=address,undefined -pthread -I src -I vendor tests/paging_driver.c $common -ldl -lm -o "$SHELF_PAGING_TEST_BIN"
cc -g -fsanitize=address,undefined -pthread -I src tests/parser_driver.c src/json.c -o "$SHELF_PARSER_TEST_BIN"
cc -g -fsanitize=address,undefined -pthread -I src -I vendor tests/recovery_driver.c $common -ldl -lm -o "$SHELF_RECOVERY_TEST_BIN"
python3 tests/parser_test.py
python3 tests/mock_server.py
python3 tests/failure_test.py
python3 tests/paging_test.py
python3 tests/recovery_test.py
build/host/disc-shelf --preview "$scratch/ui.ppm" selftest

for variant in 0 1; do
 printf 'theme_preset=10\ntheme_variant=%s\n' "$variant" > "$scratch/theme.conf"
 SHELF_THEME="$scratch/theme.conf" build/host/disc-shelf --preview "$scratch/continuous.ppm" continuous
 SHELF_THEME="$scratch/theme.conf" build/host/disc-shelf --preview "$scratch/ui.ppm" selftest
done
