#include "shelf.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static void wait_job(void) {
  for (int i = 0; i < 600; i++) {
    usleep(100000);
    pthread_mutex_lock(&shared.mu);
    int busy = shared.busy;
    pthread_mutex_unlock(&shared.mu);
    if (!busy)
      return;
  }
  fprintf(stderr, "Timed out\n");
  exit(3);
}
static void browse(int view, const char *id) {
  pthread_mutex_lock(&shared.mu);
  shared.req = (request_t){.view = view};
  if (id)
    snprintf(shared.req.id, IDLEN, "%s", id);
  shared.command = 1;
  pthread_cond_signal(&shared.wake);
  shared.busy = 1;
  pthread_mutex_unlock(&shared.mu);
  wait_job();
  printf("BROWSE %d count=%d message=%s\n", view, shared.count, shared.message);
}
int main(int argc, char **argv) {
  char err[256];
  if (!shelf_init(argv[1], err, sizeof err)) {
    fprintf(stderr, "%s\n", err);
    return 1;
  }
  pthread_t t;
  shared.busy = 1;
  pthread_create(&t, NULL, shelf_worker, NULL);
  wait_job();
  browse(ARTISTS, 0);
  browse(ALBUMS, 0);
  browse(ARTIST_ALBUMS, "artist1");
  browse(TRACKS, "album1");
  pthread_mutex_lock(&shared.mu);
  shared.picks[0] = (item_t){.kind = argc > 2 ? ALBUMS : ARTISTS};
  strcpy(shared.picks[0].id, argc > 2 ? "album1" : "artist1");
  shared.npicks = 1;
  shared.busy = 1;
  shared.command = 2;
  pthread_cond_signal(&shared.wake);
  pthread_mutex_unlock(&shared.mu);
  if (argc > 2 && !strcmp(argv[2], "cancel")) {
    usleep(500000);
    atomic_store(&abort_job, 1);
  }
  wait_job();
  printf("DOWNLOAD %s\n", shared.message);
  atomic_store(&stopping, 1);
  shelf_wake();
  pthread_join(t, NULL);
  return 0;
}
