#include "shelf.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
static void wait_job(void) {
  for (int i = 0; i < 600; i++) {
    usleep(10000);
    pthread_mutex_lock(&shared.mu);
    int b = shared.busy;
    pthread_mutex_unlock(&shared.mu);
    if (!b)
      return;
  }
  assert(0);
}
static void browse(int view, const char *id, int offset, char letter) {
  pthread_mutex_lock(&shared.mu);
  shared.req = (request_t){.view = view, .offset = offset, .letter = letter};
  if (id)
    snprintf(shared.req.id, IDLEN, "%s", id);
  shared.command = 1;
  pthread_cond_signal(&shared.wake);
  shared.busy = 1;
  pthread_mutex_unlock(&shared.mu);
  wait_job();
  assert(!shared.fatal);
}
int main(int argc, char **argv) {
  char err[256];
  assert(shelf_init(argv[1], err, sizeof err));
  pthread_t th;
  shared.busy = 1;
  pthread_create(&th, 0, shelf_worker, 0);
  wait_job();
  browse(ARTISTS, 0, 0, 0);
  assert(shared.count == 32 && shared.more && shared.total_count==10003);
  browse(ARTISTS,0,0,'A');assert(shared.total_count==10000);
  browse(ARTISTS, 0, 0, 'Z');
  assert(!strcmp(shared.rows[0].name, "Z Artist") && shared.total_count==1);
  browse(ARTISTS,0,0,'#');assert(shared.total_count==2 && shared.count==2);
  browse(ALBUMS, 0, 0, 0);
  assert(shared.count == 32);
  browse(ALBUMS, 0, 32, 0);
  assert(shared.count == 9);
  browse(ALBUMS, 0, 0, 'Z');
  assert(!strcmp(shared.rows[0].name, "Z Album"));
  browse(ARTIST_ALBUMS, "artist1", 0, 0);
  assert(shared.count == 32 && shared.total_count==70);
  browse(TRACKS, "album1", 0, 0);
  assert(shared.count == 32 && shared.total_count==40);
  browse(TRACKS, "album1", 32, 0);
  assert(shared.count == 8);
  browse(ARTIST_ALBUMS, "artist1", 32, 0);
  assert(shared.count == 32 && shared.rows[0].kind == ALBUMS);
  atomic_store(&stopping, 1);
  shelf_wake();
  pthread_join(th, 0);
  puts("PASS large artist stream, complete cardinalities, bounded viewport windows, A-Z seek, nested back "
       "navigation");
}
