# Disc Shelf 1.0.4

Standalone Navidrome collection browser and original-file downloader for the
Snowsky Disc on diskOS Disco, firmware V2.57. This package updates the app only;
it does not replace mq_ui, mq_player, firmware or signing keys.

## Install / update

Close Disc Shelf with Back to the landing screen, then Exit. On your computer,
extract Disc-Shelf-1.0.4-files.zip and open a terminal in that folder.

```sh
ssh root@192.168.178.63 '
set -e
mkdir -p /usr/data/apps/disc-shelf
if [ -f /usr/data/apps/disc-shelf/app ]; then
  cp /usr/data/apps/disc-shelf/app /usr/data/apps/disc-shelf/app.previous
fi
tar -xf - -C /usr/data/apps
chmod 755 /usr/data/apps/disc-shelf/app
/usr/data/apps/disc-shelf/app --version
' < Disc-Shelf-1.0.4-install.tar
```

The device package is an uncompressed tar for BusyBox compatibility. It contains
app, app.conf, shelf.conf.example and legal texts. It deliberately omits
shelf.conf, preserving your existing server, username, password and destination.
Source archives belong on your computer; do not extract them into the apps folder.

If you need to restore the previous app, close Disc Shelf first, then:

```sh
ssh root@192.168.178.63 '
set -e
cp /usr/data/apps/disc-shelf/app.previous /usr/data/apps/disc-shelf/app
chmod 755 /usr/data/apps/disc-shelf/app
'
```

## Configuration (new installs only)

Copy shelf.conf.example to shelf.conf on your computer and edit the values:

```ini
server=http://192.168.178.10:4533
username=YOUR_USERNAME
password=YOUR_PASSWORD
download_dir=/tmp/sdcard/Navidrome
```

Use the server base URL, without /rest, quotes or spaces around '='. The
configured destination must be on the mounted SD card, below /tmp/sdcard,
without '..'. Upload your edited file only if configuring a new install or
intentionally changing settings:

```sh
ssh root@192.168.178.63 'cat > /usr/data/apps/disc-shelf/shelf.conf; chmod 600 /usr/data/apps/disc-shelf/shelf.conf' < shelf.conf
```

Credentials remain plaintext on the device. HTTP sends them over the local
network. HTTPS depends on the Disc's installed wget and certificate chain;
certificate verification is not deliberately disabled. No credentials or media
are shipped in this package.

## Browse and download

- Landing: Disc Shelf / Navidrome browser, the faded CD tower, Browse collection,
  and Exit. The app reads the active diskOS theme and dark/light appearance on
  launch; reopening picks up changed settings.
- The full artist index starts loading at launch. Browse enables when the local
  lookup and artist preload finish. A failed preload can be retried with Browse.
  Album and track metadata loads on demand; this does not download music.
- Artists are the entry point. Tap an artist name to open all their albums; tap
  an album name to open its tracks. Back returns one level; at the root it returns
  to the landing. Exit appears only on the landing, including during startup.
- The actual diskOS Library A-Z picker stays at the right. A letter filters the
  complete artist index; '#' groups numbers and other non-A-Z initials. Changing
  groups starts at the top. Artist album views start unfiltered; their A-Z picker
  can filter the complete album list if desired.
- Continuous lists have no user-visible pages or chunks. All matching metadata
  is stored on the SD-backed catalogue, with full list cardinality. Only 32 rows
  and a bounded item window are resident in the UI; rows are reused as you scroll.
  The list follows the CD-rim profile. Returning restores the prior position.
- Selection circles are multi-select. Tap the circle to tag an item; tapping an
  artist/album name still opens it. Long press also tags. A tagged long name
  scrolls on one line. Track rows can be tapped to select directly.
- A green circle outline means local tracks were detected. For an album this is
  a presence marker, not proof the complete album exists. Already-local tracks
  cannot be tagged. Artist/album downloads check tracks and skip existing music.
- Download shows the selected count; the small cross beside the header clears
  selection. In an artist's album list or an album's track list, Download without
  explicit selections copies that artist/album, as in 1.0.3.
- Copying shows the current status, percent, transferred/expected MiB and Cancel.
  Back while working requests cancellation. Completed files stay; the current
  incomplete temporary file is removed. Continue returns to browsing.
- Existing files are never overwritten. Successful files are published only
  after the transfer completes and its size/content checks pass. There is no
  automatic library rescan: use Disco's scanner after copying.

There is no app-side edge Back or Home swipe; selection circles may sit near the
left rim. Exit and Download keep clearance from the physical lower edge.

## Validation / device status

See VALIDATION-1.0.4.txt and BUILD.json for exact checks, source digest, binary
checksums and ABI. Physical-device testing of 1.0.4 is pending. Host tests cover
10,000 artists, full album counts, A-Z/# filters, stable virtual row reuse,
navigation, selection, idle redraws, failed-response rollback, duplicate skips,
short/error responses, cancellation and 50,000-track indexed local lookup.
These checks do not establish Wi-Fi transfer speed or physical-device memory use.

## Build from included source

```sh
make CROSS=/absolute/path/to/mipsel-n2008-musl-cross/bin/mipsel-linux-musl- -j8
sh tests/run_tests.sh
```

Device output: build/mips/disc-shelf. GCC 11.2.0 / musl, MIPS32r2, FP64, NaN2008,
static link. Host output: build/host/disc-shelf. The vendored LVGL, theme engine,
fonts and SQLite source are included; no FiiO firmware is included. See LICENSE,
NOTICE.md and licenses/ for GPL/MIT/OFL and other attribution.

## Preview

```sh
make host -j8
SHELF_THEME=/path/to/diskos.conf build/host/disc-shelf --preview home.ppm home
```

Other scenes: artists, albums, selection, tracks, download, az, selftest,
continuous. Preview data is synthetic; preview mode makes no server requests.
