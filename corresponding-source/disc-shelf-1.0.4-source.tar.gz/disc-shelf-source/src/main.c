/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _GNU_SOURCE
#include "app_theme.h"
#include "azjump.h"
#include "display.h"
#include "fonts_intl.h"
#include "screens.h"
#include "shelf.h"
#include "landing.h"
#include <math.h>
#include <assert.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <unistd.h>
static lv_obj_t *landing,*row_pool[PAGE],*list_extent,*progress_bar,*progress_amount,*progress_percent;
static int total_rows,window_pending,window_delivery;
static unsigned next_generation;
static lv_obj_t *root, *content, *heading, *note, *download,
    *az, *backbtn, *exitbtn, *clearbtn, *letters, *progress_label;
static azjump_t alphabet;
static unsigned modal_hidden;
static int modal_saved;
static item_t rows[PAGE];
/* UI owns picks while idle; worker owns them until completion. No second copy.
 */
static item_t *const selected = shared.picks;
static int nrows, nselected, view = HOME, offset, revision = -1, busy = 1,
                             selecting, quit, preview_mode, fatal, reporting;
static char report_message[256],browse_message[256];
static request_t stack[4], current;
static char captions[4][STR];
static int level, rendering;
static int copying;
static volatile sig_atomic_t interrupted;
static void stop(int sig) {
  (void)sig;
  interrupted = 1;
}
static void render(void);
static void refresh_selection(void);
static int az_open(void) {
  return letters && !lv_obj_has_flag(letters, LV_OBJ_FLAG_HIDDEN);
}
static void modal_chrome(int hide) {
  lv_obj_t *items[] = {content, heading, backbtn, clearbtn, note, download, az};
  if (hide && modal_saved) return;
  if (!hide && !modal_saved) return;
  if (hide) modal_hidden = 0;
  for (unsigned i = 0; i < sizeof items / sizeof *items; i++) {
    if (!items[i]) continue;
    if (hide) {
      if (lv_obj_has_flag(items[i], LV_OBJ_FLAG_HIDDEN)) modal_hidden |= 1u << i;
      lv_obj_add_flag(items[i], LV_OBJ_FLAG_HIDDEN);
    } else if (!(modal_hidden & (1u << i)))
      lv_obj_remove_flag(items[i], LV_OBJ_FLAG_HIDDEN);
  }
  modal_saved = hide;
}
static void az_close(void) {
  if (letters) lv_obj_add_flag(letters, LV_OBJ_FLAG_HIDDEN);
  modal_chrome(0);

}
static void az_visibility(lv_event_t *e) {
  (void)e;
  if (az_open()) {
    modal_chrome(1);

  } else az_close();
}
static int set_text(lv_obj_t *obj, const char *text) {
  if (!strcmp(lv_label_get_text(obj), text))
    return 0;
  lv_label_set_text(obj, text);
  return 1;
}
static lv_obj_t *label(lv_obj_t *parent, const char *text, int x, int y, int w,
                       const lv_font_t *font) {
  lv_obj_t *l = lv_label_create(parent);
  set_text(l, text);
  lv_obj_set_pos(l, x, y);
  lv_obj_set_width(l, w);
  lv_obj_set_style_text_font(l, font, 0);
  lv_obj_set_style_text_color(l, TC(TEXT_PRIMARY), 0);
  lv_label_set_long_mode(l, LV_LABEL_LONG_DOT);
  return l;
}
static lv_obj_t *button(lv_obj_t *parent, const char *text, int x, int y, int w,
                        int h, lv_event_cb_t cb, void *data) {
  lv_obj_t *b = lv_button_create(parent);
  lv_obj_set_pos(b, x, y);
  lv_obj_set_size(b, w, h);
  lv_obj_t *l = lv_label_create(b);
  set_text(l, text);
  lv_obj_set_style_text_font(l, ui_font_cjk(16), 0);
  lv_obj_center(l);
  app_theme_button(b, 0);
  if (cb)
    lv_obj_add_event_cb(b, cb, LV_EVENT_SHORT_CLICKED, data);
  return b;
}
static int pick_index(const item_t *r) {
  for (int i = 0; i < nselected; i++)
    if (selected[i].kind == r->kind && !strcmp(selected[i].id, r->id))
      return i;
  return -1;
}
static void toggle(const item_t *r) {
  if (r->kind == TRACKS && r->local > 0)
    return;
  int i = pick_index(r);
  if (i >= 0) {
    memmove(selected + i, selected + i + 1,
            (nselected - i - 1) * sizeof *selected);
    nselected--;
  } else if (nselected < PICKS)
    selected[nselected++] = *r;
  else
    status_text("Selection limit: 256 items");
}
static void request(request_t req) {
  if (busy || fatal)
    return;
  atomic_store(&abort_job, 0);
  copying=0;
  req.generation=++next_generation;
  current = req;
  window_pending=0;window_delivery=0;
  view = req.view;
  busy = 1;
  pthread_mutex_lock(&shared.mu);
  shared.req = req;
  shared.command = 1;
  pthread_cond_signal(&shared.wake);
  shared.busy = 1;
  shared.count = 0;
  shared.done = 0;
  snprintf(shared.message, sizeof shared.message, "Loading...");
  pthread_mutex_unlock(&shared.mu);
  render();
}
static void exit_cb(lv_event_t *e) {
  (void)e;
  quit = 1;
  atomic_store(&stopping, 1);
  atomic_store(&abort_job, 1);
}
static void back_cb(lv_event_t *e) {
  (void)e;
  if (az_open()) {
    az_close();
    return;
  }
  if (busy) {
    atomic_store(&abort_job, 1);
    return;
  }
  if (reporting) {
    reporting = 0;
    if (view == HOME)
      render();
    else
      request(current);
    return;
  }
  if (level > 0) {
    level--;
    request(stack[level]);
  } else {
    view = HOME;
    current = (request_t){0};
    render();
  }
}
static void home_cb(lv_event_t *e) {
  int v = (int)(intptr_t)lv_event_get_user_data(e);
  if (busy)
    return;
  level = 0;
  strcpy(captions[0], v == ALBUMS ? "Albums" : "Artists");
  request((request_t){.view = v, .letter = 'A'});
}
static void row_event(lv_event_t *e) {
  int i = (int)(intptr_t)lv_event_get_user_data(e);
  if (i < 0 || i >= nrows || busy)
    return;
  item_t r = rows[i];
  if (lv_event_get_code(e) == LV_EVENT_LONG_PRESSED) {
    selecting = 1;
    toggle(&r);
    refresh_selection();
    return;
  }

  if (r.kind == TRACKS) {
    toggle(&r);
    selecting = 1;
    refresh_selection();
    return;
  }
  if (level >= 3)
    return;
  current.scroll_y=lv_obj_get_scroll_y(content);
  stack[level] = current;
  level++;
  snprintf(captions[level], sizeof captions[level], "%s", r.name);
  request_t req = {.view = r.kind == ARTISTS ? ARTIST_ALBUMS : TRACKS};
  snprintf(req.id, sizeof req.id, "%s", r.id);
  request(req);
}
static void scroll_page(lv_event_t *e) {
  (void)e;
  if(rendering || busy || fatal || reporting || az_open() || view==HOME)return;
  int y=lv_obj_get_scroll_y(content);if(y<0)y=0;current.scroll_y=y;
  int first=y/64;
  if(window_pending || total_rows<=PAGE || (first>=offset && first+6<offset+nrows))return;
  int off=first>6?first-6:0;
  if(off>total_rows-PAGE)off=total_rows-PAGE;if(off<0)off=0;
  if(off==offset)return;
  request_t req=current;req.offset=off;
  pthread_mutex_lock(&shared.mu);
  if(!shared.command){shared.req=req;shared.command=3;pthread_cond_signal(&shared.wake);window_pending=1;}
  pthread_mutex_unlock(&shared.mu);
}

static void download_cb(lv_event_t *e) {
  (void)e;
  if (busy) {
    atomic_store(&abort_job, 1);
    return;
  }
  if (fatal)
    return;
  if (reporting) {
    reporting = 0;
    if (view == HOME)
      render();
    else
      request(current);
    return;
  }
  if (!nselected && view != TRACKS && view != ARTIST_ALBUMS) {
    status_text("Select items using the circles");
    return;
  }
  atomic_store(&abort_job, 0);
  pthread_mutex_lock(&shared.mu);
  if (nselected) {
    shared.npicks = nselected;
  } else {
    memset(&shared.picks[0], 0, sizeof shared.picks[0]);
    shared.picks[0].kind = view == TRACKS ? ALBUMS : ARTISTS;
    snprintf(shared.picks[0].id, sizeof shared.picks[0].id, "%s", current.id);
    snprintf(shared.picks[0].name, sizeof shared.picks[0].name, "%s",
             captions[level]);
    shared.npicks = 1;
  }
  current.generation=++next_generation;window_pending=0;copying=1;
  shared.req=current;
  shared.command = 2;
  pthread_cond_signal(&shared.wake);
  shared.busy = 1;
  shared.done = 0;
  snprintf(shared.message, sizeof shared.message, "Checking missing tracks...");
  pthread_mutex_unlock(&shared.mu);
  busy = 1;
  render();
}
static void clear_cb(lv_event_t *e) {
  (void)e;
  if (busy)
    return;
  nselected = 0;
  selecting = 0;
  refresh_selection();
}
static void select_cb(lv_event_t *e) {
  int i = (int)(intptr_t)lv_event_get_user_data(e);
  if (busy || i < 0 || i >= nrows) return;
  if (rows[i].kind == TRACKS && rows[i].local > 0) return;
  selecting = 1;
  toggle(&rows[i]);
  refresh_selection();
}
static void jump_to_letter(char c) {
  az_close();
  if (busy) return;
  request_t req = current;
  req.offset = 0;
  req.scroll_y=0;
  req.letter = c;
  request(req);
}
static void az_cb(lv_event_t *e) {
  (void)e;
  if (busy || fatal || reporting || view == HOME || view == TRACKS) return;
  if (az_open()) az_close();
  else lv_obj_send_event(az, LV_EVENT_CLICKED, NULL);
}
static void curve_rows(void){
 for(int i=0;i<PAGE;i++){
  lv_obj_t *row=row_pool[i];if(!row || lv_obj_has_flag(row,LV_OBJ_FLAG_HIDDEN))continue;
  lv_area_t area;lv_obj_get_coords(row,&area);
  int dy=abs((area.y1+area.y2)/2-180),off=150-(dy<150?(int)sqrtf(150*150-dy*dy):150);
  int far=dy+30,edge=far<172?(int)sqrtf(172*172-far*far):0;
  int left=24+off;if(left<180-edge+8)left=180-edge+8;
  if(left>104)left=104;int w=300-left;
  lv_obj_set_x(row,left);lv_obj_set_width(row,w);
  lv_obj_set_width(lv_obj_get_child(row,0),w-54);
 }
}
static void curved(lv_event_t *e){(void)e;if(!rendering && view!=HOME)curve_rows();}

static void download_text(void) {
  char text[80];
  if (busy)
    strcpy(text, "Cancel");
  else if (reporting)
    strcpy(text, "Continue");
  else if (nselected)
    snprintf(text, sizeof text, "Download (%d)", nselected);
  else
    strcpy(text, "Download");
  if (set_text(lv_obj_get_child(download, 0), text))
    app_theme_button(download, 0); /* Fit the changed selection count too. */
  const lv_font_t *font=TF(UI_24);
  for(int i=0;i<4;i++){
    lv_point_t size;lv_text_get_size(&size,text,font,0,0,LV_COORD_MAX,LV_TEXT_FLAG_NONE);
    if(size.x<=lv_obj_get_width(download)-16)break;
    const lv_font_t *next=theme_font_smaller(font);if(!next || next==font)break;font=next;
  }
  lv_obj_set_style_text_font(lv_obj_get_child(download,0),font,0);
  lv_obj_set_width(heading,(selecting || nselected) && !busy && !reporting?142:190);
  if ((selecting || nselected) && view!=HOME && !busy && !reporting)
    lv_obj_remove_flag(clearbtn, LV_OBJ_FLAG_HIDDEN);
  else
    lv_obj_add_flag(clearbtn, LV_OBJ_FLAG_HIDDEN);
  if (view == HOME || fatal)
    lv_obj_add_flag(download, LV_OBJ_FLAG_HIDDEN);
  else
    lv_obj_remove_flag(download, LV_OBJ_FLAG_HIDDEN);
}
static void refresh_selection(void) {
  /* Touch feedback changes styles only: no list rebuild, no scroll jump,
   * and no deletion of the object currently dispatching the touch event. */
  if (!busy && !fatal && !reporting && view != HOME) {
    for (int i = 0; i < nrows; i++) {
      lv_obj_t *row = lv_obj_get_child(content, i);
      if (!row)
        break;
      int picked = pick_index(&rows[i]) >= 0;
      lv_obj_set_style_bg_opa(row, picked ? 255 : 0, 0);
      lv_obj_t *mark = lv_obj_get_child(row, 2);
      lv_obj_t *circle = lv_obj_get_child(mark, 0);
      lv_obj_t *dot = lv_obj_get_child(circle, 0);
      int local = rows[i].local > 0;
      lv_obj_t *name=lv_obj_get_child(row,0);
      lv_label_set_long_mode(name,picked?LV_LABEL_LONG_SCROLL_CIRCULAR:LV_LABEL_LONG_DOT);
      lv_obj_set_style_border_color(circle, local ? TC(STATUS_SUCCESS) : picked ? TC(ACCENT_PRIMARY) : TC(TEXT_SECONDARY), 0);
      lv_obj_set_style_bg_color(circle, local ? TC(TEXT_MUTED) : TC(ACCENT_PRIMARY), 0);
      lv_obj_set_style_bg_opa(circle, picked ? LV_OPA_COVER : LV_OPA_TRANSP, 0);
      if (picked) lv_obj_remove_flag(dot, LV_OBJ_FLAG_HIDDEN);
      else lv_obj_add_flag(dot, LV_OBJ_FLAG_HIDDEN);
    }
  }
  download_text();
}
static void row_create(int i){
 lv_obj_t *row=row_pool[i]=lv_obj_create(content);lv_obj_remove_style_all(row);
 lv_obj_set_size(row,276,60);lv_obj_set_style_bg_color(row,TC(SURFACE_RAISED),0);
 lv_obj_set_style_border_side(row,LV_BORDER_SIDE_BOTTOM,0);lv_obj_set_style_border_width(row,1,0);lv_obj_set_style_border_color(row,TC(BORDER),0);
 lv_obj_set_style_bg_color(row,TC(LIST_PRESSED),LV_STATE_PRESSED);lv_obj_set_style_bg_opa(row,255,LV_STATE_PRESSED);
 lv_obj_add_flag(row,LV_OBJ_FLAG_CLICKABLE);lv_obj_remove_flag(row,LV_OBJ_FLAG_SCROLLABLE);
 lv_obj_t *name=label(row,"",48,14,222,TF(UI_24));lv_obj_set_height(name,32);
 lv_obj_t *unused=label(row,"",0,0,1,TF(UI_14));lv_obj_add_flag(unused,LV_OBJ_FLAG_HIDDEN);
 lv_obj_t *mark=lv_obj_create(row);lv_obj_remove_style_all(mark);lv_obj_set_pos(mark,0,6);lv_obj_set_size(mark,44,48);
 lv_obj_remove_flag(mark,LV_OBJ_FLAG_SCROLLABLE|LV_OBJ_FLAG_EVENT_BUBBLE);lv_obj_add_flag(mark,LV_OBJ_FLAG_CLICKABLE);
 lv_obj_add_event_cb(mark,select_cb,LV_EVENT_SHORT_CLICKED,(void*)(intptr_t)i);lv_obj_add_event_cb(mark,select_cb,LV_EVENT_LONG_PRESSED,(void*)(intptr_t)i);
 lv_obj_t *circle=lv_obj_create(mark);lv_obj_remove_style_all(circle);lv_obj_set_size(circle,30,30);lv_obj_center(circle);
 lv_obj_set_style_radius(circle,LV_RADIUS_CIRCLE,0);lv_obj_set_style_border_width(circle,2,0);lv_obj_remove_flag(circle,LV_OBJ_FLAG_CLICKABLE|LV_OBJ_FLAG_SCROLLABLE);
 lv_obj_t *dot=lv_obj_create(circle);lv_obj_remove_style_all(dot);lv_obj_set_size(dot,8,8);lv_obj_center(dot);lv_obj_set_style_radius(dot,LV_RADIUS_CIRCLE,0);lv_obj_set_style_bg_color(dot,TC(ON_ACCENT),0);lv_obj_set_style_bg_opa(dot,255,0);lv_obj_remove_flag(dot,LV_OBJ_FLAG_CLICKABLE|LV_OBJ_FLAG_SCROLLABLE);
 lv_obj_add_event_cb(row,row_event,LV_EVENT_SHORT_CLICKED,(void*)(intptr_t)i);lv_obj_add_event_cb(row,row_event,LV_EVENT_LONG_PRESSED,(void*)(intptr_t)i);
}
static void render_window(void){
 rendering=1;
 for(int i=0;i<PAGE;i++){
  lv_obj_t *row=row_pool[i];if(!row)continue;
  if(i>=nrows){lv_obj_add_flag(row,LV_OBJ_FLAG_HIDDEN);continue;}
  lv_obj_remove_flag(row,LV_OBJ_FLAG_HIDDEN);lv_obj_set_y(row,(offset+i)*64);
  set_text(lv_obj_get_child(row,0),rows[i].name);
 }
 if(list_extent)lv_obj_set_y(list_extent,total_rows?total_rows*64-1:0);
 refresh_selection();lv_obj_update_layout(content);curve_rows();rendering=0;
}
static void render(void){
 az_close();rendering=1;
 if(view==HOME){
  lv_obj_remove_flag(landing,LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(content,LV_OBJ_FLAG_HIDDEN);lv_obj_add_flag(heading,LV_OBJ_FLAG_HIDDEN);lv_obj_add_flag(backbtn,LV_OBJ_FLAG_HIDDEN);lv_obj_add_flag(az,LV_OBJ_FLAG_HIDDEN);lv_obj_add_flag(clearbtn,LV_OBJ_FLAG_HIDDEN);lv_obj_add_flag(note,LV_OBJ_FLAG_HIDDEN);lv_obj_add_flag(download,LV_OBJ_FLAG_HIDDEN);
  const char *status=fatal?report_message:busy?"Loading artists...":"Ready to browse";
  shelf_home_status(status,busy||fatal);rendering=0;return;
 }
 lv_obj_add_flag(landing,LV_OBJ_FLAG_HIDDEN);lv_obj_remove_flag(content,LV_OBJ_FLAG_HIDDEN);lv_obj_remove_flag(heading,LV_OBJ_FLAG_HIDDEN);lv_obj_remove_flag(backbtn,LV_OBJ_FLAG_HIDDEN);lv_obj_add_flag(note,LV_OBJ_FLAG_HIDDEN);
 char caption[STR];const char *base=busy && copying?"Downloading":view==ARTISTS?"Artists":view==ARTIST_ALBUMS||view==ALBUMS?"Albums":captions[level];
 if(current.letter && view!=TRACKS)snprintf(caption,sizeof caption,"%.480s - %c",base,current.letter);else snprintf(caption,sizeof caption,"%s",base);
 set_text(heading,caption);
 lv_obj_remove_flag(az,LV_OBJ_FLAG_HIDDEN);if(view==TRACKS||busy||fatal||reporting)lv_obj_add_flag(az,LV_OBJ_FLAG_HIDDEN);
 memset(row_pool,0,sizeof row_pool);lv_obj_clean(content);list_extent=NULL;progress_label=NULL;progress_bar=NULL;progress_amount=NULL;progress_percent=NULL;
 if(reporting||fatal){progress_label=label(content,report_message,44,20,230,TF(UI_20));lv_label_set_long_mode(progress_label,LV_LABEL_LONG_WRAP);}
 else if(busy){
  progress_label=label(content,"Loading...",44,8,240,TF(UI_20));lv_obj_set_height(progress_label,56);lv_label_set_long_mode(progress_label,LV_LABEL_LONG_WRAP);
  progress_percent=label(content,"",44,66,240,TF(UI_48));lv_obj_set_style_text_align(progress_percent,LV_TEXT_ALIGN_CENTER,0);
  progress_bar=lv_bar_create(content);lv_obj_set_pos(progress_bar,60,134);lv_obj_set_size(progress_bar,240,10);lv_obj_set_style_bg_color(progress_bar,TC(CONTROL_TRACK),0);lv_obj_set_style_bg_color(progress_bar,TC(ACCENT_PRIMARY),LV_PART_INDICATOR);
  progress_amount=label(content,"",44,152,240,TF(UI_20));lv_obj_set_style_text_align(progress_amount,LV_TEXT_ALIGN_CENTER,0);
 }else{
  for(int i=0;i<PAGE;i++)row_create(i);
  list_extent=lv_obj_create(content);lv_obj_remove_style_all(list_extent);lv_obj_set_size(list_extent,1,1);lv_obj_remove_flag(list_extent,LV_OBJ_FLAG_CLICKABLE|LV_OBJ_FLAG_SCROLLABLE);
  render_window();lv_obj_scroll_to_y(content,current.scroll_y,LV_ANIM_OFF);lv_obj_update_layout(content);curve_rows();
  if(!total_rows){lv_obj_remove_flag(note,LV_OBJ_FLAG_HIDDEN);set_text(note,browse_message[0]?browse_message:"No matching results");}
 }
 download_text();rendering=0;
}

static void tick(lv_timer_t *timer){
 (void)timer;
 if(az_open())return;
 /* Keep a row under the finger stable while a viewport result is delivered. */
 for(lv_indev_t *in=lv_indev_get_next(NULL);in;in=lv_indev_get_next(in))if(lv_indev_get_state(in)==LV_INDEV_STATE_PRESSED)return;
 int redraw=0;int64_t bytes,total;char text[256];int b;
 pthread_mutex_lock(&shared.mu);
 b=shared.busy;bytes=shared.byte_done;total=shared.byte_total;
 snprintf(text,sizeof text,"%s",shared.message);
 if(shared.revision!=revision){
  revision=shared.revision;
  if(shared.result_generation==current.generation || shared.fatal){
   window_delivery=window_pending && !b && !shared.done && shared.view==view && shared.total_count>0;
   snprintf(browse_message,sizeof browse_message,"%s",text);
   window_pending=0;fatal=shared.fatal;nrows=shared.count;total_rows=shared.total_count;
   memcpy(rows,shared.rows,nrows*sizeof *rows);offset=shared.offset;current.offset=offset;
   if(view!=HOME)current.letter=shared.letter;
   if(fatal)snprintf(report_message,sizeof report_message,"%s",text);
   if(shared.done){reporting=1;snprintf(report_message,sizeof report_message,"%s",text);if(shared.done==1){nselected=0;selecting=0;}}
   busy=b;redraw=1;
  }
 }
 pthread_mutex_unlock(&shared.mu);
 if(redraw){if(window_delivery && row_pool[0])render_window();else render();}
 if(view==HOME)shelf_home_status(fatal?report_message:text,busy||fatal);
 if(progress_label && busy){
  set_text(progress_label,text);
  char amount[96];if(total>0)snprintf(amount,sizeof amount,"%.1f / %.1f MiB",bytes/1048576.0,total/1048576.0);else amount[0]=0;
  if(progress_amount)set_text(progress_amount,amount);
  if(progress_bar && total>0){int percent=(int)(bytes*100/total);lv_bar_set_value(progress_bar,percent,LV_ANIM_OFF);char value[16];snprintf(value,sizeof value,"%d%%",percent);if(progress_percent)set_text(progress_percent,value);}
 }
 if(!busy && view!=HOME)scroll_page(NULL);
}

static void build(void) {
  root = lv_screen_active();
  lv_obj_set_style_bg_color(root, TC(CANVAS), 0);
  lv_obj_remove_flag(root, LV_OBJ_FLAG_SCROLLABLE);
  landing=shelf_home_create(root,home_cb,exit_cb);
  heading = label(root,"Disc Shelf",121,37,142,TF(UI_24));
  lv_obj_set_height(heading,32);
  lv_obj_set_style_text_align(heading, LV_TEXT_ALIGN_LEFT, 0);
  backbtn = button(root, "<", 72, 30, 42, 42, back_cb, NULL);
  exitbtn=shelf_home_exit();
  content = lv_obj_create(root);
  lv_obj_remove_style_all(content);
  lv_obj_set_pos(content,0,84);
  lv_obj_set_size(content,304,194);
  lv_obj_set_scroll_dir(content, LV_DIR_VER);
  lv_obj_set_scrollbar_mode(content, LV_SCROLLBAR_MODE_OFF);
  lv_obj_add_event_cb(content, curved, LV_EVENT_SCROLL, NULL);
  lv_obj_add_event_cb(content, scroll_page, LV_EVENT_SCROLL, NULL);
  lv_obj_add_event_cb(content, scroll_page, LV_EVENT_SCROLL_END, NULL);
  note =
      label(root, "Checking local library...", 54, 176, 252, TF(UI_20));
  lv_obj_set_height(note, 70);
  lv_label_set_long_mode(note, LV_LABEL_LONG_WRAP);
  lv_obj_set_style_text_align(note, LV_TEXT_ALIGN_CENTER, 0);
  download = button(root, "Download", 66, 282, 228, 48, download_cb, NULL);
  azjump_create(&alphabet, root, jump_to_letter, "library");
  az = alphabet.btn;
  letters = alphabet.grid;
  /* Retain the Library rim position, leaving room for the app Download footer. */
  lv_obj_set_pos(az, 308, 158);
  lv_obj_set_size(az, 44, 44);
  lv_obj_set_ext_click_area(az, 4);
  lv_obj_align(lv_obj_get_child(letters, 0), LV_ALIGN_TOP_MID, -25, 20);
  lv_obj_add_event_cb(az, az_visibility, LV_EVENT_CLICKED, NULL);
  lv_obj_add_event_cb(letters, az_visibility, LV_EVENT_CLICKED, NULL);
  clearbtn = button(root, LV_SYMBOL_CLOSE, 270, 50, 32, 32, clear_cb, NULL);
  render();
  lv_timer_create(tick, 200, NULL);
}
int main(int argc, char **argv) {
  if(argc==2 && !strcmp(argv[1],"--version")){puts("Disc Shelf 1.0.4");return 0;}
  if (argc == 4 && !strcmp(argv[1], "--fetch")) {
    pid_t parent = (pid_t)strtol(argv[2], NULL, 10);
    if (prctl(PR_SET_PDEATHSIG, SIGKILL) || getppid() != parent)
      return 1;
    char *av[] = {"wget", "-q", "-O", "-", "-T", "15", argv[3], NULL};
    execvp("wget", av);
    return 1;
  }
  preview_mode = (argc == 3 || argc == 4) && !strcmp(argv[1], "--preview");
  const char *conf = getenv("SHELF_CONFIG");
  if (!conf)
    conf = "/usr/data/apps/disc-shelf/shelf.conf";
  char error[256] = "";
  int ready = preview_mode || shelf_init(conf, error, sizeof error);
  struct sigaction sa = {0};
  sa.sa_handler = SIG_DFL;
  sigaction(SIGCHLD, &sa, NULL);
  signal(SIGTERM, stop);
  signal(SIGINT, stop);
  struct rlimit core = {0, 0};
  setrlimit(RLIMIT_CORE, &core);
  FILE *f = fopen("/proc/self/oom_score_adj", "w");
  if (f) {
    fputs("500", f);
    fclose(f);
  }
  lv_init();
  if (!display_open(preview_mode)) {
    display_close();
    return 1;
  }
  app_theme_init(preview_mode ? getenv("SHELF_THEME") : NULL);
  build();
  pthread_t worker;
  int started = 0;
  if (preview_mode) {
    const char *scene = argc == 4 ? argv[3] : "albums";
    busy = 0;
    view = !strcmp(scene, "home")      ? HOME
           : !strcmp(scene, "artists") ? ARTISTS
           : !strcmp(scene, "tracks")  ? TRACKS
                                       : ALBUMS;
    snprintf(captions[0], sizeof captions[0], "%s",
             view == HOME      ? "Disc Shelf"
             : view == ARTISTS ? "Artists"
             : view == TRACKS  ? "Kind of Blue"
                               : "Albums");
    const char *names[] = {"Kind of Blue", "Discovery", "Blue Train",
                           "Homogenic"};
    const char *artists[] = {"Air", "Aphex Twin", "Autechre", "Alice Coltrane"};
    const char *tracks[] = {"So What", "Freddie Freeloader", "Blue in Green",
                            "All Blues"};
    nrows = !strcmp(scene, "selftest") || !strcmp(scene,"continuous") ? PAGE : 4;
    for (int i = 0; i < nrows; i++) {
      rows[i].kind = view == ARTISTS  ? ARTISTS
                     : view == TRACKS ? TRACKS
                                      : ALBUMS;
      snprintf(rows[i].id, IDLEN, "demo%d", i);
      snprintf(rows[i].name, STR, "%s",
               view == ARTISTS  ? artists[i % 4]
               : view == TRACKS ? tracks[i % 4]
                                : names[i % 4]);
      snprintf(rows[i].artist, STR, "%s",
               view == TRACKS ? "Miles Davis" : artists[i % 4]);
      rows[i].count = 8 + i;
      rows[i].local = (view == TRACKS && i == 0) || (view == ALBUMS && i == 2);
    }
    if (!strcmp(scene, "selection")) {
      selecting = 1;
      toggle(&rows[0]);
      toggle(&rows[1]);
    }
    current.view=view;shared.view=view;
    current.letter=shared.letter=view==ARTISTS?'A':0;
    shared.count = nrows;
    shared.total_count = nrows;
    memcpy(shared.rows, rows, nrows * sizeof *rows);
    shared.more = view != HOME;
    snprintf(shared.message, sizeof shared.message, "%s",
             view == HOME ? "Ready to browse"
                          : "");
    if (!strcmp(scene, "download")) {
      copying=1;
      shared.busy = 1;
      shared.byte_done = 17 * 1024 * 1024;
      shared.byte_total = 42 * 1024 * 1024;
      snprintf(shared.message, sizeof shared.message,
               "Downloading So What\n3 saved / 2 already local");
    }
    shared.revision = 1;
    tick(NULL);
    if (!strcmp(scene, "az"))
      az_cb(NULL);
    lv_refr_now(NULL);
    display_save(argv[2]);
    if(!strcmp(scene,"continuous")){
      uint32_t physical=lv_obj_get_child_count(content);lv_obj_t *stable=row_pool[0];
      total_rows=shared.total_count=10000;lv_obj_set_y(list_extent,10000*64-1);lv_obj_update_layout(content);
      lv_obj_scroll_to_y(content,6400,LV_ANIM_OFF);lv_obj_update_layout(content);scroll_page(NULL);
      assert(shared.command==3 && window_pending);
      request_t want=shared.req;shared.command=0;shared.offset=want.offset;shared.count=PAGE;
      shared.result_generation=current.generation;shared.view=view;shared.revision++;
      for(int i=0;i<PAGE;i++)snprintf(shared.rows[i].name,STR,"Artist %d",want.offset+i);
      tick(NULL);lv_obj_update_layout(content);
      assert(row_pool[0]==stable && lv_obj_get_child_count(content)==physical);
      assert(lv_obj_get_scroll_y(content)==6400 && total_rows==10000);
      assert(offset==want.offset && !window_pending);
      unsigned accepted=current.generation;current.generation=accepted+1;
      shared.result_generation=accepted;shared.offset=0;shared.revision++;tick(NULL);
      assert(offset==want.offset); /* stale response cannot replace this view */
      puts("PASS: continuous 10,000-item scroll range, stable row pool, position retained, stale results discarded");
    }
    if (!strcmp(scene, "selftest")) {
      lv_obj_scroll_to_y(content, 90, LV_ANIM_OFF);
      lv_refr_now(NULL);
      int scroll = lv_obj_get_scroll_y(content);
      lv_obj_t *row = lv_obj_get_child(content, 2);
      lv_obj_send_event(row, LV_EVENT_LONG_PRESSED, NULL);
      lv_refr_now(NULL);
      assert(nselected == 1 && lv_obj_get_child(content, 2) == row);
      assert(lv_obj_get_scroll_y(content) == scroll);
      clear_cb(NULL);
      lv_refr_now(NULL);
      assert(nselected == 0 && lv_obj_get_scroll_y(content) == scroll);
      lv_obj_t *selector = lv_obj_get_child(row, 2);
      lv_obj_send_event(selector, LV_EVENT_SHORT_CLICKED, NULL);
      assert(nselected == 1 && !shared.command);
      lv_obj_send_event(selector, LV_EVENT_SHORT_CLICKED, NULL);
      assert(nselected == 0 && !shared.command);
      assert(lv_obj_get_scroll_y(content) == scroll);
      clear_cb(NULL);
      lv_refr_now(NULL);
      unsigned flushed = display_flush_count();
      for (int i = 0; i < 100; i++) {
        usleep(20000);
        lv_timer_handler();
      }
      assert(display_flush_count() == flushed);
      az_cb(NULL);
      lv_obj_update_layout(root);
      assert(az_open() && !lv_obj_is_visible(exitbtn));
      lv_obj_send_event(letters, LV_EVENT_CLICKED, NULL);
      lv_obj_update_layout(root);
      assert(!az_open() && !lv_obj_is_visible(exitbtn));
      az_cb(NULL);
      back_cb(NULL);
      assert(!az_open() && !lv_obj_has_flag(az, LV_OBJ_FLAG_HIDDEN));
      lv_obj_send_event(selector, LV_EVENT_SHORT_CLICKED, NULL);
      assert(nselected == 1);
      lv_obj_send_event(row, LV_EVENT_SHORT_CLICKED, NULL);
      assert(shared.command == 1 && current.view == TRACKS && nselected == 1);
      busy=0;shared.command=0;level=0;view=ARTISTS;
      back_cb(NULL);lv_obj_update_layout(root);
      assert(view==HOME && lv_obj_is_visible(exitbtn));
      lv_obj_send_event(exitbtn, LV_EVENT_SHORT_CLICKED, NULL);
      assert(quit && atomic_load(&stopping));
      puts("PASS long-press retains row and scroll, Clear retains scroll, idle "
           "UI redraws=0 over 2 seconds, selection circle toggles, Library A-Z dismissal, name navigation while selected, landing-only Exit");
    }
  } else {
    if (ready) {
      shared.busy = 1;
      pthread_attr_t attr;
      pthread_attr_init(&attr);
      /* musl's small default stack is unsafe for bounded recursive JSON + IO.
       */
      int attr_ok = pthread_attr_setstacksize(&attr, 256 * 1024) == 0;
      started = attr_ok && !pthread_create(&worker, &attr, shelf_worker, NULL);
      pthread_attr_destroy(&attr);
      if (!started) {
        busy = shared.busy = 0;
        fatal = shared.fatal = 1;
        snprintf(shared.message, sizeof shared.message,
                 "Cannot start app worker.");
        snprintf(report_message, sizeof report_message, "%s", shared.message);
        render();
      }
    } else {
      busy = 0;
      fatal = 1;
      shared.fatal = 1;
      shared.busy = 0;
      snprintf(shared.message, sizeof shared.message, "%s", error);
      snprintf(report_message, sizeof report_message, "%s", error);
      render();
      set_text(note, error);
    }
    while (!quit && !interrupted) {
      uint32_t wait = lv_timer_handler();
      if (wait < 5)
        wait = 5;
      if (wait > 50)
        wait = 50;
      usleep(wait * 1000);
    }
    atomic_store(&stopping, 1);
    atomic_store(&abort_job, 1);
    if (started) {
      shelf_wake();
      pthread_join(worker, NULL);
    } else
      shelf_close();
  }
  lv_deinit();
  display_close();
  return 0;
}
