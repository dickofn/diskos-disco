/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#define PAGE 32
#define PICKS 256
#define STR 512
#define IDLEN 160
enum { HOME, ARTISTS, ALBUMS, TRACKS, ARTIST_ALBUMS };
typedef struct {
  int kind, track, disc, count, local;
  int64_t size;
  char id[IDLEN], name[STR], artist[STR], album[STR], suffix[24], cover[IDLEN];
} item_t;
typedef struct {
  int view, offset, scroll_y;
  unsigned generation;
  char id[IDLEN], letter;
} request_t;
typedef struct {
  pthread_mutex_t mu;
  pthread_cond_t wake;
  item_t rows[PAGE];
  int count, total_count, more, offset, view, revision, busy, done, fatal;
  unsigned result_generation;
  char letter;
  char message[256];
  item_t picks[PICKS];
  int npicks;
  int64_t byte_done, byte_total;
  request_t req;
  int command;
} shared_t;
extern shared_t shared;
extern atomic_int stopping, abort_job;
int shelf_init(const char *conf, char *err, size_t cap);
void *shelf_worker(void *arg);
void shelf_close(void);
void shelf_wake(void);
int api_fetch(const char *endpoint, const char *args, const char *file,
              int64_t max, int64_t expected, int media);
int parse_response(const char *file, int (*emit)(const item_t *, void *),
                   void *ctx);
void url_encode(const char *s, char *out, size_t cap);
void status_text(const char *fmt, ...);
int available_memory(void);
int storage_headroom(uint64_t extra);
int shelf_sd_ready(void);
