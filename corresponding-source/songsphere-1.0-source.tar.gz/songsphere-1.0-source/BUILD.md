# Building SongSphere 1.0

From the diskOS Disco! repository (the complete build): `make -C ui CROSS=<mipsel-linux-musl->-prefix> songsphere`,
with the toolchain described in ui/toolchain/mcm-config.mak (GCC 11.2, musl 1.2.6, MIPS32r2 FP64 NaN2008).
This archive holds the files that build uses: ui/songsphere, ui/fb_pan.c/.h, ui/controls.h, ui/lv_conf.h, the Inter
fonts, SQLite and LVGL 9.2.2. Compile each .c with
`-Os -std=gnu11 -static -pthread -D_GNU_SOURCE -DLV_CONF_INCLUDE_SIMPLE -ffunction-sections -fdata-sections -O2 -Iui`
and link them with `-static -pthread -Wl,--gc-sections -lm -lrt`.
